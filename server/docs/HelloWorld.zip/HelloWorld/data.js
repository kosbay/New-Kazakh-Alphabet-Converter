﻿WidgetCallback([
   {
       "image_url": "images/widget.gif",
       "text": " World ",
       "description": " My First Widget",
       "id": "1"
   }
]);